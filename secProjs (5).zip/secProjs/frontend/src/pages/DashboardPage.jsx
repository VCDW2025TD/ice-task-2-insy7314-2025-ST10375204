const DashboardPage = () => {
    return (
      <div>
        <h2>Dashboard</h2>
        <p>Welcome! You are logged in.</p>
      </div>
    );
  };
  
  export default DashboardPage;
  